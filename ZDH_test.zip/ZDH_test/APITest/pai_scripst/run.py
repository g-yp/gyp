from APITest.pai_scripst.api_logins import UserTest
import flask

server = flask.Flask(__name__)

@server.route('/register', methods=['get', 'post'])
def register():
    #注册接口
    return UserTest().register()

@server.route('/login', methods=['get', 'post'])
def login():
    #登录接口
    return UserTest().login()

server.run(debug=True, port=8888, host='0.0.0.0')  # 指定端口,host,0.0.0.0不管几个网卡，任何ip都可访问
