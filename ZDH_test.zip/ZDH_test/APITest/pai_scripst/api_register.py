from APITest.pai_scripst.api_mysql import Api_Sql
import flask,json
from flask import request

# server = flask.Flask(__name__)
#
# @server.route('/register', methods=['get', 'post'])
class RegiSter():

    def register(self):
        #获取通过url请求传参的数据
        username = request.values.get('name')
        #获取url请求传的密码，明文
        pwd=request.values.get('pwd')
        #sqlusername
            # 数据库查询用户名
        #判断用户名、密码都不为空，如果不传用户名、密码则username和pwd为None

        if username and pwd:
            sqlusername = Api_Sql().select_sql(username)

            if type(sqlusername) == type(()) :

                    # sql插入用户名，密码
                    Api_Sql().inster_sql(username, pwd)
                    resu = {'code': 200, 'message': '注册成功'}
                    return json.dumps(resu, ensure_ascii=False)
                    # 将字典转换为Json串，json是字符串
            else:
                    resu={'code':-1,'message':'已注册'}
                    return json.dumps(resu,ensure_ascii=False)#将字典转换为Json串，json是字符串

        else:
            resu={'code':-3,'message':'账号密码不能为空'}
            return json.dumps(resu,ensure_ascii=False)

# server.run(debug=True, port=8888, host='0.0.0.0')  # 指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问
#
#
# if __name__== '__main__':
#     server.run(debug=True,port = 8888,host='0.0.0.0')#指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问
