from APITest.scripts.handle_mysql import do_mysql

class Api_Sql():

    def do_mysql1(self,sql1):

        return do_mysql.run(sql1, is_more=True)

    def name_sql(self,url_name):
        # 根据urlname 获取数据库username，pwd  登录sql
        name = 'SELECT * FROM user where username = "{}"'.format(url_name)
        name1 = do_mysql.run(name, is_more=True)
        sqlname = name1[0]['username']
        sqlpwd = name1[0]['password']

        if sqlname == url_name:
            return sqlname, sqlpwd
        else:
            pass

    def select_sql(self,url_name):
        #查询sel
        sql = 'SELECT * FROM user where username = "{}"'.format(url_name)
        a  = do_mysql.run(sql, is_more=True)
        return a

    def inster_sql(self, name,pwd):

        sql = "INSERT INTO `USER`(username,PASSWORD) VALUES ('{}','{}')".format(name,pwd)
        do_mysql.run(sql, is_more=True)

if __name__ == '__main__':

    sql = Api_Sql().select_sql('1243234')
    print (sql)
    # if sqlname != None:
        #     return '该用户已注册'
        # else:
        #     "INSERT INTO `USER`(username,PASSWORD) VALUES ('{}','{}')".format(register_name,register_pwd)
