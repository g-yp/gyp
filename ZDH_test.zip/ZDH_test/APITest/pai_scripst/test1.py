from APITest.scripts.handle_mysql import HandleMysql
# #数据库插入图片
# fin = open('C:/Users/EDZ/Desktop/gz/photo1.png','rb')
# img = fin.read()
# fin.close()
# sql = 'insert into test_ptoto(id,pic_data) values (%s,%s)'
# args = ('3',img)
# HandleMysql().run(sql,args)
#读取图片
sql = 'select * from test_ptoto where id = %s'
args = ('3')
aa =  HandleMysql().run(sql,args)
print(aa)

# sql1 = 'SELECT * FROM user where username = "21434543"'
# # a1 = "INSERT INTO `USER`(username,PASSWORD) VALUES ('1234','43543')"
# do_mysql = HandleMysql()
# result1 = do_mysql.run(sql1, is_more=True)
# # result2 = do_mysql.run(a1, is_more=True)
#
# print(type(result1))