from flask import Flask
app = Flask(__name__)
#
# # @app.route('/')
# # def hello_world():
# #     return 'Hello World!'
# # @app.route('/hello/')
# # def hello():
# #     return '123435 World'
# # @app.route('/user/<username>')
# # def show_user_profile(username):
# #     # show the user profile for that user
# #     return 'User %s' % username
# # @app.route('/haha/<int:post_id>')  #只接受int类型
# # def show_post(post_id):
# #     # show the post with the given id, the id is an integer
# #     return 'haha %d' % post_id
# if __name__ == '__main__':
#     app.debug = True  #dug模式，不能用于生产环境
#     app.run(host='0.0.0.0')

from flask import request

with app.test_request_context('/hello', method='POST'):
    # now you can do something with the request until the
    # end of the with block, such as basic assertions:
    assert request.path == '/hello'
    assert request.method == 'POST'