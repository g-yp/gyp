# -*- coding: utf-8 -*-
"""
-------------------------------------------------
  @Time : 2019/7/16 21:37 
  @Auth : 可优
  @File : test_03_recharge.py
  @IDE  : PyCharm
  @Motto: ABC(Always Be Coding)
-------------------------------------------------
"""
import unittest
import json

from libs.ddt import ddt, data

from scripts.handle_excel import HandleExcel
from scripts.handle_config import do_config
from scripts.handle_log import do_logger
from scripts.constants import TEST_DATAS_FILES_PATH
from scripts.handle_context import Context
from scripts.handle_request import HttpRequest
from scripts.handle_mysql import HandleMysql

do_excel = HandleExcel(TEST_DATAS_FILES_PATH, 'recharge')
cases = do_excel.get_cases()


@ddt
class TestRecharge(unittest.TestCase):
    """
    充值接口测试类
    """

    @classmethod
    def setUpClass(cls):
        cls.do_request = HttpRequest()
        cls.handle_mysql = HandleMysql()  # 创建HandleMysql对象
        do_logger.info("\n{:=^40s}".format("开始执行注册接口用例"))

    @classmethod
    def tearDownClass(cls):
        cls.do_request.close()
        cls.handle_mysql.close()
        do_logger.info("\n{:=^40s}".format("结束执行注册接口用例"))

    @data(*cases)
    def test_recharge(self, one_case):
        # do_request = HttpRequest()
        new_data = Context.recharge_parameterization(one_case['data'])
        new_url = do_config.get_value('api', 'prefix_url') + one_case['url']
        check_sql = one_case['check_sql']
        if check_sql:
            check_sql = Context.recharge_parameterization(check_sql)
            mysql_data = self.handle_mysql.run(check_sql)   # decimal.Decimal类型
            amount_before_recharge = float(mysql_data["LeaveAmount"])
            amount_before_recharge = round(amount_before_recharge, 2)

        # 向服务器发起请求
        res = self.do_request.to_request(method=one_case['method'],
                                         url=new_url,
                                         data=new_data)
        # 期望值
        expect_result = one_case['expected']
        msg = "测试" + one_case['title']
        success_msg = do_config.get_value("msg", "success_result")
        fail_msg = do_config.get_value("msg", "fail_result")
        case_id = one_case['case_id']
        # code = res.json().get('code')
        try:
            # self.assertEqual(str(expect_result), code, msg=msg)
            self.assertIn(str(expect_result), res.text, msg=msg)
            if check_sql:
                mysql_data = self.handle_mysql.run(check_sql)  # decimal.Decimal类型
                amount_after_recharge = float(mysql_data["LeaveAmount"])  # 充值之后的投资金额
                amount_after_recharge = round(amount_after_recharge, 2)
                one_dict = json.loads(new_data, encoding='utf-8')
                current_recharge_amount = one_dict.get("amount")  # 获取当前充值金额

                actual_amount = round(amount_before_recharge + current_recharge_amount, 2)
                self.assertEqual(actual_amount,
                                 amount_after_recharge,
                                 msg="数据库中充值的金额有误")
            do_excel.write_result(case_id+1, res.text, success_msg)
            do_logger.debug("{}, 执行结果为: {}".format(msg, success_msg))
        except AssertionError as e:
            do_excel.write_result(case_id+1, res.text, fail_msg)
            do_logger.error("{}, 执行结果为: {}具体异常为: {}".format(msg, fail_msg, e))
            raise e


if __name__ == '__main__':
    unittest.main()
