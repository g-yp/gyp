
import unittest

from libs.ddt import ddt, data

from scripts.handle_excel import HandleExcel
from scripts.handle_config import do_config
from scripts.handle_log import do_logger
from scripts.constants import TEST_DATAS_FILES_PATH
from scripts.handle_context import Context
from scripts.handle_request import HttpRequest

do_excel = HandleExcel(TEST_DATAS_FILES_PATH, 'register')
cases = do_excel.get_cases()


@ddt
class TestRegister(unittest.TestCase):
    """
    注册接口测试类
    """

    @classmethod
    def setUpClass(cls):
        cls.do_request = HttpRequest()
        do_logger.info("\n{:=^40s}".format("开始执行注册接口用例"))

    @classmethod
    def tearDownClass(cls):
        cls.do_request.close()
        # do_logger.info("{}".format("用例执行结束"))
        do_logger.info("\n{:=^40s}".format("结束执行注册接口用例"))

    @data(*cases)
    def test_register(self, one_case):
        # data = one_case['data']     # 需要进行参数化
        new_data = Context.register_parameterization(one_case['data'])
        # 获取真实值
        # url = one_case['url']
        new_url = do_config.get_value('api', 'prefix_url') + one_case['url']
        # 向服务器发起请求
        res = TestRegister.do_request.to_request(method=one_case['method'],
                                                 url=new_url,
                                                 data=new_data)
        # 期望值
        expect_result = one_case['expected']
        msg = "测试" + one_case['title']
        success_msg = do_config.get_value("msg", "success_result")
        fail_msg = do_config.get_value("msg", "fail_result")
        case_id = one_case['case_id']
        try:
            # 第一个参数为期望值
            self.assertEqual(expect_result, res.text, msg=msg)
            do_excel.write_result(case_id+1, res.text, success_msg)
            do_logger.debug("{}, 执行结果为: {}".format(msg, success_msg))
        except AssertionError as e:
            print(new_data)
            do_excel.write_result(case_id+1, res.text, fail_msg)
            do_logger.error("{}, 执行结果为: {}具体异常为: {}".format(msg, fail_msg, e))
            raise e


if __name__ == '__main__':
    unittest.main()
