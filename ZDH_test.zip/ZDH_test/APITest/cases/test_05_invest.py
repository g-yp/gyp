
import unittest
import json

from libs.ddt import ddt, data

from scripts.handle_excel import HandleExcel
from scripts.handle_config import do_config
from scripts.handle_log import do_logger
from scripts.constants import TEST_DATAS_FILES_PATH
from scripts.handle_context import Context
from scripts.handle_request import HttpRequest
from scripts.handle_mysql import HandleMysql

do_excel = HandleExcel(TEST_DATAS_FILES_PATH, 'invest')
cases = do_excel.get_cases()

# 1. 使用全局变量来解决接口依赖的问题, 极有可能出现循环导入的问题, 会抛出异常
# 2. 多次导入同一个模块, 只有一个模块会导入成功, 同时导入的变量不会改变
# loan_id = 0


@ddt
class TestInvest(unittest.TestCase):
    """
    投资接口测试类
    """
    @classmethod
    def setUpClass(cls):
        cls.do_request = HttpRequest()
        cls.handle_mysql = HandleMysql()  # 创建HandleMysql对象
        do_logger.info("\n{:=^40s}".format("开始执行投资接口用例"))

    @classmethod
    def tearDownClass(cls):
        cls.do_request.close()
        cls.handle_mysql.close()
        do_logger.info("\n{:=^40s}".format("结束执行投资接口用例"))

    @data(*cases)
    def test_invest(self, one_case):
        new_data = Context.invest_parameterization(one_case['data'])
        new_url = do_config.get_value('api', 'prefix_url') + one_case['url']
        # 向服务器发起请求
        res = self.do_request.to_request(method=one_case['method'],
                                         url=new_url,
                                         data=new_data)

        # print(f"res.text = {res.text}")
        if "加标成功" in res.text:
            check_sql = one_case['check_sql']
            if check_sql:
                check_sql = Context.invest_parameterization(check_sql)
                mysql_data = self.handle_mysql.run(check_sql)
                # global loan_id
                # 动态修改或者获取变量的一个过程
                # Context.loan_id = mysql_data.get('Id')  # 类属性
                setattr(Context, "loan_id", mysql_data.get('Id'))  # 给一个对象动态创建属性

        # 期望值
        expect_result = one_case['expected']
        msg = "测试" + one_case['title']
        success_msg = do_config.get_value("msg", "success_result")
        fail_msg = do_config.get_value("msg", "fail_result")
        case_id = one_case['case_id']
        try:
            # self.assertEqual(str(expect_result), code, msg=msg)
            self.assertIn(str(expect_result), res.text, msg=msg)
            do_excel.write_result(case_id+1, res.text, success_msg)
            do_logger.debug("{}, 执行结果为: {}".format(msg, success_msg))
        except AssertionError as e:
            do_excel.write_result(case_id+1, res.text, fail_msg)
            do_logger.error("{}, 执行结果为: {}具体异常为: {}".format(msg, fail_msg, e))
            raise e


if __name__ == '__main__':
    unittest.main()
