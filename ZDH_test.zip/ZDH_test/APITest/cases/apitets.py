# import flask
# import json
# server = flask.Flask(__name__)
# from APITest.API_text.handle_mysql import HandleMysql
#
# @server.route('/index' ,methods = ['get'])
# def index():
#     a1  = str(1.2)
#     id = flask.request.values.get('id')
#
#     if  id:
#         sql1 = 'SELECT * FROM testuser where id =  '+id
#         do_mysql = HandleMysql()
#         result1 = do_mysql.run(sql1, is_more=True)
#         return json.dumps(result1)
#     else:
#         return "{'msg':'id为空','msg_code':1}"
#
#
# @server.route('/login' ,methods = ['get'])
# def login():
#     phone = flask.request.values.get('phone')
#     password = flask.request.values.get('password')
#     if  phone and password :
#         # sql1 = 'SELECT * FROM testuser where phone =  '+id
#         # do_mysql = HandleMysql()
#         # result1 = do_mysql.run(sql1, is_more=True)
#         # a = "phone:{},password:{}".format(phone,password)
#         a = {'phone':phone,'password':password}
#         return json.dumps(a)
#     else:
#         "{'phone':'手机号为空','password':'密码为空'}"
#         return
#
# server.run(port=8999,debug=True)
#
from APITest.scripts.handle_mysql import HandleMysql
import flask,json
from flask import request

def do_mysql(sql1):
    do_mysql = HandleMysql()
    return do_mysql.run(sql1, is_more=True)

def name_sql(url_name=None):
    #根据urlname 获取数据库username，pwd
    name = 'SELECT * FROM user where username = "{}"'.format(url_name)
    name1 = do_mysql(name)
    sqlname = name1[0]['username']
    sqlpwd = name1[0]['password']

    if sqlname == url_name:
        return sqlname,sqlpwd
    else:
        pass

#创建一个服务，把当前这个python文件当做一个服务
server = flask.Flask(__name__)
#server.route()可以将普通函数转变为服务　登录接口的路径、请求方式
@server.route('/login',methods=['get','post'])
def login():
    #获取通过url请求传参的数据
    username = request.values.get('name')
    #获取url请求传的密码，明文
    pwd=request.values.get('pwd')
    #sqlusername,pwd
    try:
            sqlusername = name_sql(username)[0]
            sqlpwd = name_sql(username)[1]
        #判断用户名、密码都不为空，如果不传用户名、密码则username和pwd为None

            if username and pwd:
                if username == sqlusername and pwd == sqlpwd:
                    resu={'code':200,'message':'登录成功'}
                    return json.dumps(resu,ensure_ascii=False)#将字典转换为Json串，json是字符串
                else:
                    resu={'code':-1,'message':'密码错误'}
                    return json.dumps(resu,ensure_ascii=False)

            else:
                resu={'code':-3,'message':'密码不能为空'}
                return json.dumps(resu,ensure_ascii=False)
    except :
        resu = {'code': -2, 'message': '用户名输入有误'}
        return json.dumps(resu, ensure_ascii=False)


if __name__== '__main__':
    server.run(debug=True,port = 8888,host='0.0.0.0')#指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问


'''
flask: seb框架，通过flask提供的装饰器@server.route()将普通函数转换为服务
登录接口，需要传入url,username,passwd
'''
#创建一个服务，把当前这个python文件当做一个服务server