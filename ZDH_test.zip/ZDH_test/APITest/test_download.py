from APITest.scripts.handle_mysql import HandleMysql
import flask,json
from flask import make_response
from flask import request
#下载文件
server = flask.Flask(__name__)
@server.route('/testdownload',methods=['get','post'])
def testdownload():
    content = "long text"
    response = make_response(content)
    response.headers["Content-Disposition"] = "attachment; filename=myfilename.txt"
    return response

#读取服务器上的文件下载
from flask import make_response , send_file
@server.route('/testdownload1',methods=['get','post'])
def testdownload1():
    response = make_response(send_file("views.py"))
    response.headers["Content-Disposition"] = "attachment; filename=views.py;"
    return response

if __name__== '__main__':
    server.run(debug=True,port = 8888,host='0.0.0.0')#指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问


