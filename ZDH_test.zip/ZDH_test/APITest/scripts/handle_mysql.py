
import random

import pymysql

from APITest.scripts.handle_config import do_config


class HandleMysql:
    """
    处理mysql
    """

    def __init__(self):
        self.conn = pymysql.connect(host=do_config.get_value('mysql', 'host'),
                                    user=do_config.get_value('mysql', 'user'),
                                    password=do_config.get_value('mysql', 'password'),
                                    db=do_config.get_value('mysql', 'db'),
                                    port=do_config.get_int('mysql', 'port'),
                                    charset=do_config.get_value('mysql', 'charset'),
                                    cursorclass=pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()

    # def get_value(self, sql, args=None):
    #     self.cursor.execute(sql, args)
    #     self.conn.commit()
    #
    #     return self.cursor.fetchone()
    #
    # def get_values(self, sql, args=None):
    #     self.cursor.execute(sql, args)
    #     self.conn.commit()
    #
    #     return self.cursor.fetchall()

    def run(self, sql, args=None, is_more=False):
        self.cursor.execute(sql, args)
        self.conn.commit()

        if is_more:
            return self.cursor.fetchall()
        else:
            return self.cursor.fetchone()

    def close(self):
        #查询关闭数据库
        # 关闭游标
        self.cursor.close()
        # 关闭连接
        self.conn.close()

    def saver_update_close(self):
        # # 关闭游标
        # self.cursor.close()
        # 关闭连接
        self.conn.close()
    @staticmethod
    def create_mobile():
        """
        随机生成11位手机号
        :return: 返回一个手机号字符串
        """
        start_mobile = ['138', '139', '158', '180', '188', '189']
        start_num = random.choice(start_mobile)
        end_num = ''.join(random.sample('0123456789', 8))

        return start_num + end_num

    def is_existed_mobile(self, mobile):
        """
        判断给定的手机号在数据库中是否存在
        :param mobile: 11位手机号组成的字符串
        :return: True or False
        """
        sql = "SELECT MobilePhone FROM member WHERE MobilePhone=%s;"
        if self.run(sql, args=(mobile,)):  # 手机号已经存在，则返回True，否则返回False
            return True
        else:
            return False

    def create_not_existed_mobile(self):
        """
        随机生成一个在数据库中不存在的手机号
        :return: 返回一个手机号字符串
        """
        while True:
            one_mobile = self.create_mobile()
            if not self.is_existed_mobile(one_mobile):
                break

        return one_mobile

    def get_existed_moblie(self):
        """
        获取一个在数据库中已经存在的手机号
        :return: 返回一个手机号字符串
        """
        sql = "SELECT MobilePhone FROM member LIMIT 0, 1;"
        one_mobile = self.run(sql)  # 获取数据库中第一个手机号

        return one_mobile["MobilePhone"]
do_mysql = HandleMysql()

if __name__ == '__main__':
    sql1 = 'SELECT * FROM user where username = "21434543"'
    # a1 = "INSERT INTO `USER`(username,PASSWORD) VALUES ('1234','43543')"
    do_mysql = HandleMysql()
    result1 = do_mysql.run(sql1, is_more=True)
    # result2 = do_mysql.run(a1, is_more=True)


    print(type(result1))





    #
    # result2 = do_mysql.run(sql2, args=('15921919560', ))
    # print(result2)
