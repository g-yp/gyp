from datas.random_number import RanDom
random_num = RanDom().random_num()
random_str_hz = RanDom().random_str_hz()
random_Letter = RanDom().random_Letter()
rhgl_page_data = {
    'true': 11,
    'int':random_num,
    'str':random_str_hz,
    'str1':random_Letter,
    'float':'12.2'
}
#正常输入跟输入数字
rwgl_rwspgl_add_data_sucess = [
    (random_str_hz,random_num,'http://www.baodu.com',random_Letter,'/Users/apple/Desktop/图片/timg.gif'),
    (random_num,random_num, random_num,random_num, '/Users/apple/Desktop/图片/timg.gif')
]

#输入汉字跟字符
rwgl_rwspgl_add_data_file = [
    (random_str_hz,random_str_hz,random_str_hz,random_str_hz, '/Users/apple/Desktop/图片/timg.gif'),
    (random_Letter,random_Letter,random_Letter,random_Letter, '/Users/apple/Desktop/图片/timg.gif')
]
#图片不输入
rwgl_rwspgl_add_data_file1 = [
    (random_str_hz,random_num,'http://www.baodu.com',random_Letter)
]

