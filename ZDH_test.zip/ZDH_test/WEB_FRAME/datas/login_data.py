oms_datas = {
    'url':'https://me.aishepin8.com/#/login?s=omstest&redirect=https%3A%2F%2Fomstest.aishepin8.com%2Fgoods-center',
}
yx_data = {
    'url': 'window.open("https://exmail.qq.com/cgi-bin/loginpage?t=logindomain&s=logout&f=biz&param=guoyupeng@ibaodashi.com")',
    'username':'guoyupeng@ibaodashi.com',
    'pwd':'1259851353aA'
}
