import random,string

class RanDom:
    '''随机生成'''
    def random_str_hz(self):
        '''随机生成五位数汉字'''
        val = random.randint(0x4e00, 0x9fbf)
        a = chr(val) * 5
        return a

    def random_num(self):
        '''随机生成数字'''
        a = string.digits
        val = random.sample(a, 8)
        b = ''
        return b.join(val)

    def random_Letter(self):
        '''随机生成字母'''
        s = string.ascii_lowercase  # 所有小写字母(a-z)
        # s=string.ascii_letters #所有大小写字母(a-z,A-Z)
        # s=string.ascii_uppercase #所有大写字母(A-Z)
        return random.choice(s) * 5

if __name__ == '__main__':
    a = RanDom().random_num()
    print(a)