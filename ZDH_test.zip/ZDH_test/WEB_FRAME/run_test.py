#
# import os
# import unittest
# from datetime import datetime
#
# from WEB_FRAME.libs import HTMLTestRunnerNew
# from WEB_FRAME.scripts.constants import REPORTS_DIR
# from WEB_FRAME.scripts.handle_config import do_config
# from WEB_FRAME.scripts.constants import CASES_DIR
#
# one_suite = unittest.defaultTestLoader.discover(CASES_DIR)
#
# # 3.运行用例
# # datetime.strftime(datetime.now(), "%Y%m%d%H%M%S")
# report_name = do_config.get_value("report", "report_html_name") + "_" + \
#               datetime.strftime(datetime.now(), "%Y%m%d%H%M%S") + '.html'
# report_full_path = os.path.join(REPORTS_DIR, report_name)
# with open(report_full_path, mode='wb') as save_to_file:
#     one_runner = HTMLTestRunnerNew.HTMLTestRunner(stream=save_to_file,
#                                                   title=do_config.get_value("report", "title"),
#                                                   verbosity=do_config.get_int("report", "verbosity"),
#                                                   description=do_config.get_value("report", "description"),
#                                                   tester=do_config.get_value("report", "tester"))
#     one_runner.run(one_suite)
# from selenium import webdriver
# import pprint,time
# driver = webdriver.Chrome()
# driver.implicitly_wait(20)
# driver.get('https://exmail.qq.com/cgi-bin/loginpage?t=logindomain&s=logout&f=biz&param=guoyupeng@ibaodashi.com')
# # iframe = driver.find_element_by_name('iframe_distributeDomain_proxy_')    #获取by_name,其他的有漏洞
# # driver.switch_to.frame(iframe)
#
# a = driver.find_element_by_xpath('//*[@id="loginForm"]/div[5]/h1').text()
# print(a)
# # a =  '//input[@type="submit"and@id="btlogin"]'
# # driver.find_element_by_xpath(a).click()
for i in range(1,6):
    print(i)