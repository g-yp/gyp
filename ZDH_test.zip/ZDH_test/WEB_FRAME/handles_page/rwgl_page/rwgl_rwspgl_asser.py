from pages.basepage import BasePage
from selenium.webdriver.common.by import By
import time
class AssEr(BasePage):

    '''任务管理/任务视频管理/断言数据'''

    sucess_asser_xpath_ok = (By.XPATH, '//*[@id="example"]/tbody/tr[1]/td[3]')
    sucess_asser_xpath = (By.XPATH, '//*[@id="example"]/thead/tr/th[4]')

    rwspgl_xpath = (By.XPATH, '//a[text()="任务视频管理"]')
    srbt_xpath = (By.XPATH, '//input[@class="form-control input-sm"and@placeholder="请输入标题"]')
    djcx_xpath = (By.XPATH, '//input[@class="btn btn-success waves-effect waves-light"and@value="查询"]')
    tjcg_asser_xpath = (By.XPATH, '//*[@id="example"]/tbody/tr[1]/td[3]')
    tjsb_asser_xpath = (By.XPATH, '//a[text()="任务视频管理"]')
    file_asser = (By.XPATH, '//*[@id="page-404"]/div/div/div')
    file_asser1 = (By.XPATH, '//*[@for="inputPassword3"and text()="奖励金币数"]')


    def sucess_asser_ok(self):
        '''点击查询已存在断言'''
        time.sleep(2)
        return self.wait_presence_element(self.sucess_asser_xpath_ok).text

    def sucess_asser(self):
        '''点击查询未存在断言'''
        time.sleep(2)
        return self.wait_presence_element(self.sucess_asser_xpath).text

    def tjcg_asser(self):
        '''添加成功断言'''
        time.sleep(2)

        return self.wait_presence_element(self.tjcg_asser_xpath).text

    def tjsb_asser(self):
        '''添加失败断言_不添加图片'''

        return self.wait_presence_element(self.file_asser).text

    def tjsb_asser1(self):
        '''添加失败断言_金币输入框输入错误'''

        return self.wait_presence_element(self.file_asser1).text


