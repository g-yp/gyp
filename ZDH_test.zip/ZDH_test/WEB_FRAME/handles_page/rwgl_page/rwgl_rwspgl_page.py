from pages.basepage import BasePage
from selenium.webdriver.common.by import By
import time
class RwGl(BasePage):

    '''任务管理/任务视频管理/查询封装'''

    rwgl_xpath = (By.XPATH, '//span[text()="任务管理"]')
    rwspgl_xpath = (By.XPATH, '//a[text()="任务视频管理"]')
    srbt_xpath = (By.XPATH, '//input[@class="form-control input-sm"and@placeholder="请输入标题"]')
    djcx_xpath = (By.XPATH, '//input[@class="btn btn-success waves-effect waves-light"and@value="查询"]')
    djqk_xpath = (By.XPATH, '//button[@class="btn btn-success waves-effect waves-light"and @value="Reset"]')
    add_xpath = (By.XPATH, '//*[@id="example_filter"]/label/a')
    dwbt_xpath = (By.XPATH, '//*[@name="title"and @placeholder="请填写标题"]')
    jljbs_xpath = (By.XPATH, '//*[@name="coin"and @placeholder="请填写奖励金币数"]')
    spbqdz_xpath = (By.XPATH, '//*[@name="mark"and @placeholder="请填写视频标签地址"]')
    yybm_xpath = (By.XPATH, '//*[@name="pkname"and @placeholder="请填写应用包名"]')
    spfm_xpath = (By.XPATH, '//*[@name="img"and @class="dropify"]')
    tj_xpath = (By.XPATH, '//*[@type="submit"and @class="btn btn-info btn-sm waves-effect waves-light"]')
    djgb_xpath = (By.XPATH, '//a[text() = "返回"and@class="btn btn-success"]')


    def mkdj(self):
        '''公共模块点击，任务管理/任务视频管理/'''
        time.sleep(1)
        self.rwgl_page().click()
        time.sleep(1)
        self.respgl_page().click()


    def ss_test(self,value):
        '''开始查询'''
        self.srbt_page().send_keys(value)
        self.click_logins().click()
        self.srbt_page().clear()  #清空输入框

    def add_test(self,value,value1,value2,value3,value4=None):
        '''新增测试'''
        self.page_add().click()
        self.Location_heading().send_keys(value)
        self.Location_jljbs().send_keys(value1)
        self.Location_spbqdz().send_keys(value2)
        self.Location_yybm().send_keys(value3)
        if value4!=None:
            self.Location_spfm().send_keys(value4)
        self.tj().click()

    def rwgl_page(self):
        '''点击任务管理'''
        return self.wait_visible_element(self.rwgl_xpath)
    def respgl_page(self):
        '''点击任务视频管理'''
        return self.wait_visible_element(self.rwspgl_xpath)
    def srbt_page(self):
        '''输入标题'''
        return self.wait_visible_element(self.srbt_xpath)
    def click_logins(self):
        '''点击查询'''
        return self.wait_visible_element(self.djcx_xpath)
    def page_add(self):
        '''点击新增'''
        return self.wait_visible_element(self.add_xpath)
    def Location_heading (self):
        '''定位标题'''
        return self.wait_visible_element(self.dwbt_xpath)
    def Location_jljbs(self):
        '''定位奖励金币数'''
        return self.wait_visible_element(self.jljbs_xpath)
    def Location_spbqdz(self):
        '''定位视频标签地址'''
        return self.wait_visible_element(self.spbqdz_xpath)
    def Location_yybm(self):
        '''定位应用包名'''
        return self.wait_visible_element(self.yybm_xpath)
    def Location_spfm(self):
        '''定位视频封面'''
        return self.wait_presence_element(self.spfm_xpath)
    def tj(self):
        '''点击提交'''
        return self.wait_visible_element(self.tj_xpath)
    def djgb(self):
        '''图片不选择后，点击关闭'''
        return self.wait_visible_element(self.djgb_xpath)



