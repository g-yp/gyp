from WEB_FRAME.pages.basepage import BasePage
from selenium.webdriver.common.by import By
from WEB_FRAME.datas.login_data import yx_data,oms_datas

class YXLogin_Page(BasePage):

    '''登录邮箱获取验证码，登录oms'''

    user_elem_xpath = (By.XPATH, '//input[@type="text"and @placeholder="邮箱帐号"]')
    pwd_elem_xpath = (By.XPATH, '//input[@type="password"and @placeholder="输入邮箱密码"]')
    click_login = (By.XPATH, '//input[@class="login_btn"and @id="btlogin"]')
    #点击收件箱
    sjx_click = (By.XPATH, '//div[@id="resize"]//a[@id="folder_1"]/b[1]')
    #邮件切换iframe
    iframe_xpath = (By.XPATH, '//*[@id="mainFrame"]')
    #邮箱内切换iframe
    iframe_yx_xpath = (By.XPATH, '//*[@id="mainFrame"and @name="mainFrame"]')
    #获取get邮件码
    get_path = (By.XPATH, '//*[@id="mailContentContainer"]')

    #oms邮箱登录
    oms_yx_send = (By.XPATH, '//*[@type="text"and @autocomplete="off"]')
    oms_yzm_click = (By.XPATH, '//*[@class="el-icon-message"]')
    oms_yzm_send = (By.XPATH, '//*[@class="el-input el-input-group el-input-group--append"]/input')
    oms_yzm_alert = (By.XPATH, '//*[@class="el-button el-button--default el-button--small el-button--primary "]')
    oms_click =  (By.XPATH, '//*[@class="el-button el-button--primary"]/span')



    def yj_text(self,path):
        '''邮件定位'''
        yj_text_xpath = (By.XPATH, '//*[@id="frm"]/div[@class="toarea"]/table[{}]/tbody/tr/td[3]/table/tbody/tr/td[1]/nobr'.format(path))
        return yj_text_xpath

    def url_oms(self, url):
        '''登录开始'''
        self.driver.get(url)
        return self.current()

    def url_yx(self, url):

        self.driver.execute_script(url)
        return self.current()

    # @property元素 转换成类方法
    def user_elem(self, value):
        '''定位用户输入框'''
        return

    # @property
    def yx_login_elem(self,user_name,pwd):
        '''邮箱登录'''
        self.wait_presence_element(self.user_elem_xpath).send_keys(user_name)
        self.wait_presence_element(self.pwd_elem_xpath).send_keys(pwd)
        self.wait_presence_element(self.click_login).click()

    def yzm_test(self):
        '''获取比较收件邮箱标题'''
        self.wait_presence_element(self.sjx_click).click()
        self.switch_iframe(self.iframe_xpath)

        try:
            a = 1
            while True:
                a1 = self.wait_presence_element(self.yj_text(a)).text
                if a1 in 'git  ' :
                    self.wait_presence_element(self.yj_text(a)).click()
                    self.switch_iframe_defauil()
                    self.switch_iframe(self.iframe_yx_xpath)
                    a2 = self.wait_presence_element(self.get_path).text
                    break
                else:
                    a += 1
            return a2
        except Exception as a :
            return '未找到git邮箱',a

    def oms_yx(self,value):
        '''oms输入邮箱账号'''
        self.wait_presence_element(self.oms_yx_send).send_keys(value)
        self.wait_presence_element(self.oms_yzm_click).click()
        self.wait_presence_element(self.oms_yzm_alert).click()



    def run(self):
        '''邮箱登录获取验证码'''
        # oms发送验证码
        self.url_oms(oms_datas['url'])
        yx = self.url_yx(yx_data['url'])
        self.oms_yx(yx_data['username'])
        self.driver.switch_to_window(yx[1])
        self.yx_login_elem(yx_data['username'],yx_data['pwd'])
        a = self.yzm_test()
        self.driver.switch_to_window(yx[0])
        self.wait_presence_element(self.oms_yzm_send).send_keys(a)
        import time
        time.sleep(3)
        self.wait_presence_element(self.oms_click).click()





