from WEB_FRAME.pages.basepage import BasePage
from selenium.webdriver.common.by import By
from WEB_FRAME.datas.random_number import RanDom
from WEB_FRAME.datas.login_data import yx_data
RanDom1 = RanDom()
#商品管理
spgl = (By.XPATH, '//ul[@role="menubar" and @class="el-menu" ]/li[9]//span[contains(text(),"商品管理")]')
#自建商品
zjsp = (By.XPATH, '//ul[@role="menubar" and @class="el-menu" ]/li[9]//li[contains(text(),"自建商品")]')
#新建商品
xjsp = (By.XPATH, '//*[@type="button" and @class="el-button el-button--primary el-button--default" ]/span[contains(text(),"新建商品")]')
#商品名称
a = 'test'
spmc1 = (By.XPATH, '//*[@class="el-form"]/div[1]//input[@type="text" and @autocomplete="off"]')
#原文案
ywa = (By.XPATH, '//*[@class="el-form"]/div[2]//input[@type="text" and @autocomplete="off"]')
#商品品牌
sppp_click = (By.XPATH, '//*[@class="el-form"]/div[3]//input[@type="text" and @autocomplete="off"]')
sppp_send = (By.XPATH, '//div[@class="el-select-dropdown el-popper"and @x-placement="bottom-start"]//li[3]')
#所属分类
ssfl = (By.XPATH, '//*[@class="el-form"]/div[4]//input[@type="text" and @autocomplete="off"]')
ssfl1 = (By.XPATH,"//span[text()='箱包手袋']")
ssfl2= (By.XPATH, "//span[text()='女士箱包']")
ssfl3 = (By.XPATH, "//span[text()='单肩包']")
#所属系列
ssxl = (By.XPATH, '//*[@class="el-form"]/div[5]//input[@type="text" and @autocomplete="off"]')
#商品成色
spcs = (By.XPATH, '//*[@class="el-form"]/div[6]//input[@type="text" and @autocomplete="off"]')
spcs1 = (By.XPATH, "//span[text()='新品']")
#市场价
scj = (By.XPATH, '//*[@class="el-form"]/div[7]//input[@type="text" and @autocomplete="off"]')
#零售价
lsj = (By.XPATH, '//*[@class="el-form"]/div[8]//input[@type="text" and @autocomplete="off"]')
#合作价
hzj = (By.XPATH, '//*[@class="el-form"]/div[9]//input[@type="text" and @autocomplete="off"]')
#库存
kc = (By.XPATH, '//*[@class="el-form"]/div[10]//input[@type="text" and @autocomplete="off"]')

#商品来源
sply = (By.XPATH, '//*[@class="goods-form-content"]/div[1]//input[@type="text" and @autocomplete="off"]')
#商品来源-自营
sply_zy = (By.XPATH, '//span[text()="自营"]')
#商品来源-自营-自采日期
zy_zcrq = (By.XPATH, '//*[@class="goods-form-content"]/div[5]//input[@type="text" and @autocomplete="off"]')

#商品来源-个人寄卖
sply_grjm  = (By.XPATH, '//span[text()="个人寄卖"]')
#商品来源-个人寄卖-物品签码
grjm_wpqm = (By.XPATH, '//*[@class="goods-form-content"]/div[4]//input[@type="text" and @autocomplete="off"]')

#商品来源-合作门店
sply_hzmd  = (By.XPATH, '//span[text()="合作门店"]')   #精准查询
#所占数量
szsl = (By.XPATH, '//*[@class="goods-form-content"]/div[2]//input[@type="text" and @autocomplete="off"]')
#商品位置
spwz = (By.XPATH, '//*[@class="goods-form-content"]/div[3]//input[@type="text" and @autocomplete="off"]')
#门店名称
mdmc = (By.XPATH, '//*[@class="goods-form-content"]/div[6]//input[@type="text" and @autocomplete="off"]')

#添加尺码详情
tjcmxq = (By.XPATH, '//span[contains(text(),"添加尺码详情")]')  #模糊查询
#商品尺码
spcm = (By.XPATH, '//*[@class="new-build-goods"]//*[@class="el-dialog__wrapper"]//*[@class="el-form-item is-required el-form-item--default"][1]//input')
#该尺码库存数量
cmkcsl = (By.XPATH, '//*[@class="new-build-goods"]//*[@class="el-dialog__wrapper"]//*[@class="el-form-item is-required el-form-item--default"][2]//input')
#确定按钮
qdan = (By.XPATH, '//*[@class="el-dialog__footer"]//*[contains(text(),"确 定")]')
#商品颜色
spys = (By.XPATH, '//*[@class="el-form"]/div[13]//input[@type="text" and @autocomplete="off"]')
#商品材质
spcz = (By.XPATH, '//*[@class="el-form"]/div[14]//input[@type="text" and @autocomplete="off"]')
#当前状态
dqzt = (By.XPATH, '//*[@class="el-form"]/div[15]//input[@type="text" and @autocomplete="off"]')
#当前状态-在售中
dqzt_zsz = (By.XPATH, '//span[text()="在售中"]')


class OMSLogin_Page(BasePage):

    def oms_sqgl(self):
        #商品管理
        self.wait_presence_element(spgl).click()
    def oms_zjsp(self):
        #自建商品
        self.wait_presence_element(zjsp).click()
    def oms_xjsp(self):
        #新建商品
        self.wait_presence_element(xjsp).click()

    def oms_spmc(self,data):
        #输入商品名称
        self.wait_presence_element(spmc1).send_keys(a+'商品名称'+data)

    def oms_ywa(self,data):
        #输入原文案
        self.wait_presence_element(ywa).send_keys(a+'原文案'+data)

    def oms_sppp(self):
        # 输入商品品牌
        self.wait_presence_element(sppp_click).click()
        self.wait_presence_element(sppp_send).click()

    def oms_ssfl(self):
        # 输入所属分类
        self.wait_presence_element(ssfl).click()
        self.wait_presence_element(ssfl1).click()
        self.wait_presence_element(ssfl2).click()
        self.wait_presence_element(ssfl3).click()

    def oms_ssxl(self):
        # 所属系列
        pass
    def oms_sscs(self):
        #商品成色
        self.wait_presence_element(spcs).click()
        self.wait_presence_element(spcs1).click()
    def oms_scj(self,data):
        #市场价
        self.wait_presence_element(scj).send_keys(data)
    def oms_lsj(self,data):
        #零售价
        self.wait_presence_element(lsj).send_keys(data)
    def oms_hzj(self,data):
        #合作价
        self.wait_presence_element(hzj).send_keys(data)
    def oms_kc(self,data):
        #库存
        self.wait_presence_element(kc).send_keys(data)
    def oms_sply(self,data):
        #库存
        self.wait_presence_element(kc).send_keys(data)


    def run(self):
        self.oms_sqgl()
        self.oms_zjsp()
        self.oms_xjsp()
        self.oms_spmc(RanDom1.random_num())
        self.oms_ywa(RanDom1.random_num())
        self.oms_sppp()
        self.oms_ssfl()
        self.oms_ssxl()




