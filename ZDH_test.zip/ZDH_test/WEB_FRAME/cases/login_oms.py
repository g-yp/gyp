from WEB_FRAME.scripts.handle_log import do_logger
from WEB_FRAME.datas.login_data import yx_data
from WEB_FRAME.handles_page.yxlogin_page import YXLogin_Page
from WEB_FRAME.handles_page.oms import OMSLogin_Page

from selenium import webdriver
import unittest
class Test_oms(unittest.TestCase):

    @classmethod
    def setUpClass(cls) -> None:

        '''访问oms'''
        do_logger.info("\n{:=^40s}".format("oms开始测试"))
        cls.driver = webdriver.Chrome()
        cls.driver.maximize_window()
        cls.driver.implicitly_wait(20)

    @classmethod
    def tearDownClass(cls) -> None:
        do_logger.info("\n{:=^40s}".format("结束执行任务管理/任务视频管理/新增测试"))
        # cls.driver.quit()

    def setUp(self) -> None:
        '''发送邮件获取git验证码,oms登录'''
        self.login_yx_mos = YXLogin_Page(self.driver)
        self.test_mos = OMSLogin_Page(self.driver)
        self.login_yx_mos.run()


    def tearDown(self) -> None:
        self.driver.quit()

    def test1(self):
        self.test_mos.run()


if __name__ == '__main__':
    unittest.main()
