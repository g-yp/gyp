from datas.login_data import login_datas
from datas.rwgl_data import rhgl_page_data
from handles_page.login_page import Login_Page
from handles_page.rwgl_page.rwgl_rwspgl_asser import AssEr
from handles_page.rwgl_page.rwgl_rwspgl_page import RwGl
from ddt import ddt,data
from scripts.handle_log import do_logger
from selenium import webdriver
import unittest

@ddt
class TestBtxx(unittest.TestCase):

    '''标题查询功能测试'''

    @classmethod
    def setUpClass(cls) -> None:

        '''开始执行'''
        do_logger.info("\n{:=^40s}".format("开始执行标题查询功能测试"))

        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(20)
        #登录
        cls.rwgl = RwGl(cls.driver)
        cls.login_page = Login_Page(cls.driver)
        cls.login_page.login(login_datas['url'],
                             login_datas['username'],
                             login_datas['password'])
        #运行模块点击，运行一次
        cls.rwgl.mkdj()
        cls.asser = AssEr(cls.driver)

    @classmethod
    def tearDownClass(cls) -> None:
        '''执行结束'''
        do_logger.info("\n{:=^40s}".format("结束执行标题查询功能测试"))

        cls.driver.quit()

    @data(*rhgl_page_data.values())
    def test_ztcs_data(self,one_data):

        self.rwgl.ss_test(one_data)
        msg = '标题查询功能测试'
        if one_data == 11:
            assert_page_ok = self.asser.sucess_asser_ok()
            try:
                self.assertEqual(int(assert_page_ok), 11)  # 断言结果
                print('搜索"{}"断言成功'.format(assert_page_ok))
                do_logger.debug("{}, 执行结果为: {}".format(msg, assert_page_ok))

            except AssertionError as e:
                print('搜索"{}"断言失败'.format(e))
                do_logger.error("{}, 执行结果为: 具体异常为: {}".format(msg, e))

        else:
            assert_page =str(self.asser.sucess_asser())

            try:
                self.assertIn(assert_page, '奖励金币数：')  # 断言结果
                print('搜索"{}"断言成功'.format(one_data,assert_page))
                do_logger.debug("{}, 执行结果为: {}".format(msg, assert_page))

            except AssertionError as e:
                print('搜索"{}"断言失败'.format(e))
                do_logger.error("{}, 执行结果为: 具体异常为: {}".format(msg, e))


if __name__ == '__main__':
    unittest.main()