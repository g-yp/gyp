from WEB_FRAME.datas.login_data import login_datas
# from datas.rwgl_data import rwgl_rwspgl_add_data_sucess,rwgl_rwspgl_add_data_file,rwgl_rwspgl_add_data_file1
# from handles_page.login_page import Login_Page
from WEB_FRAME.handles_page.rwgl_page.rwgl_rwspgl_asser import AssEr
# from handles_page.rwgl_page.rwgl_rwspgl_page import RwGl
from ddt import ddt,data
from WEB_FRAME.scripts.handle_log import do_logger

from selenium import webdriver
import unittest

@ddt
class TestBtxx(unittest.TestCase):
    '''任务管理/任务视频管理/新增'''
    @classmethod
    def setUpClass(cls) -> None:

        '''访问oms'''
        do_logger.info("\n{:=^40s}".format("oms开始测试"))

        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(20)
        cls.rwgl = RwGl(cls.driver)
        cls.login_page = Login_Page(cls.driver)
        cls.login_page.login(login_datas['url'],
                             login_datas['username'],
                             login_datas['password'])

        # 运行模块点击,运行一次
        cls.rwgl.mkdj()
        cls.asser = AssEr(cls.driver)

    @classmethod
    def tearDownClass(cls) -> None:
        do_logger.info("\n{:=^40s}".format("结束执行任务管理/任务视频管理/新增测试"))

        cls.driver.quit()

    def setUp(self) -> None:
        # 运行模块点击
        self.rwgl.respgl_page().click()
        self.msg = '标题查询功能测试'


    def tearDown(self) -> None:
        pass

    @data(*rwgl_rwspgl_add_data_sucess)
    def test_dycg1(self,one_data):
        '''成功添加断言'''
        self.rwgl.add_test(one_data[0],
                           one_data[1],
                           one_data[2],
                           one_data[3],
                           one_data[4])
        assert_page_ok = self.asser.tjcg_asser()
        try:
            self.assertIn(str(assert_page_ok), one_data[0])  # 断言结果
            print('正常输入断言成功:{}'.format(assert_page_ok))
            do_logger.debug("{}, 执行结果为: {}".format(self.msg, assert_page_ok))

        except AssertionError as e:
            print('正常输入断言失败:{}'.format(e))
            do_logger.error("{}, 执行结果为: 具体异常为: {}".format(self.msg, e))

    @data(*rwgl_rwspgl_add_data_file1)
    def test_dycg2(self,one_data):

        '''图片不选择断言'''
        self.rwgl.add_test(one_data[0],
                           one_data[1],
                           one_data[2],
                           one_data[3]
                           )
        assert_page_ok = self.asser.tjsb_asser()
        try:
            self.assertIn(str(assert_page_ok),'请添1加封面图')  # 断言结果
            print('图片不选择断言断言成功:{}'.format(assert_page_ok))
            do_logger.debug("{}, 执行结果为: {}".format(self.msg, assert_page_ok))

        except AssertionError as e:
            print('图片不选择断言断言失败:{}'.format(e))
            do_logger.error("{}, 执行结果为: 具体异常为: {}".format(self.msg, e))

        #点击关闭
        self.rwgl.djgb().click()


    @data(*rwgl_rwspgl_add_data_file)
    def test_dycg3(self,one_data):

        '''图片不选择断言'''
        self.rwgl.add_test(one_data[0],
                           one_data[1],
                           one_data[2],
                           one_data[3],
                           one_data[4]

                           )
        assert_page_ok = self.asser.tjsb_asser1()
        try:
            self.assertIn(str(assert_page_ok),'请填写奖励金币数')  # 断言结果
            print('金币输入非数字断言成功:{}'.format(assert_page_ok))
            do_logger.debug("{}, 执行结果为: {}".format(self.msg, assert_page_ok))

        except AssertionError as e:
            print('金币输入非数字断言失败:{}'.format(e))
            do_logger.error("{}, 执行结果为: 具体异常为: {}".format(self.msg, e))

if __name__ == '__main__':
    unittest.main()